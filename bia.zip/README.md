## Project BIA for trainning deploy

#### Run migrations

```
docker compose exec server bash -c 'npx sequelize db:create'
```

#### Run migrations

```
docker compose exec server bash -c 'npx sequelize db:migrate'
```
